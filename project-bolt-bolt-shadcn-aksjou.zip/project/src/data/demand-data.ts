import { DemandData } from '@/types/charts';

export const demandData: DemandData[] = [
  { name: 'Mon', food: 40, electronics: 24, clothing: 18 },
  { name: 'Tue', food: 30, electronics: 28, clothing: 22 },
  { name: 'Wed', food: 45, electronics: 26, clothing: 15 },
  { name: 'Thu', food: 50, electronics: 32, clothing: 20 },
  { name: 'Fri', food: 55, electronics: 36, clothing: 25 },
  { name: 'Sat', food: 60, electronics: 40, clothing: 30 },
  { name: 'Sun', food: 48, electronics: 30, clothing: 28 },
];