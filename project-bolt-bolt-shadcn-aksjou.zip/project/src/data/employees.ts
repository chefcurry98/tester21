import { Employee } from "@/types/employee";

export const employeesData: Employee[] = [
  {
    id: "EMP-001",
    name: "John Doe",
    email: "john.doe@eirconnect.com",
    role: "driver",
    status: "active",
    joinDate: "2024-01-15",
    phone: "+353 83 123 4567",
    deliveriesCompleted: 156,
    rating: 4.8
  },
  {
    id: "EMP-002",
    name: "Jane Smith",
    email: "jane.smith@eirconnect.com",
    role: "dispatcher",
    status: "active",
    joinDate: "2023-11-20",
    phone: "+353 83 234 5678"
  },
  {
    id: "EMP-003",
    name: "Mike Johnson",
    email: "mike.j@eirconnect.com",
    role: "driver",
    status: "onLeave",
    joinDate: "2023-08-10",
    phone: "+353 83 345 6789",
    deliveriesCompleted: 243,
    rating: 4.9
  }
];