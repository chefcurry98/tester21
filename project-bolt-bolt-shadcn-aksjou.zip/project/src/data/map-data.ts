import { Delivery, Driver } from '@/types/map';

export const deliveriesData: Delivery[] = [
  {
    id: 'del-1',
    coordinates: [-6.2603, 53.3498],
    status: 'In Progress',
    address: '123 Main St, Dublin',
    driver: 'John Doe'
  },
  {
    id: 'del-2',
    coordinates: [-6.2488, 53.3557],
    status: 'Pending',
    address: '456 Oak Ave, Dublin',
    driver: 'Jane Smith'
  }
];

export const driversData: Driver[] = [
  {
    id: 'drv-1',
    coordinates: [-6.2570, 53.3520],
    name: 'John Doe',
    status: 'Active'
  },
  {
    id: 'drv-2',
    coordinates: [-6.2450, 53.3480],
    name: 'Jane Smith',
    status: 'Active'
  }
];