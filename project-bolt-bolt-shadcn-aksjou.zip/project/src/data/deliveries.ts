import { Delivery } from "@/types/delivery";

export const deliveriesData: Delivery[] = [
  {
    id: "DEL-001",
    pickup: "123 Main St, Dublin",
    delivery: "456 Oak Ave, Dublin",
    status: "inProgress",
    driver: "John Doe",
    createdAt: "2024-03-20T10:00:00Z",
  },
  {
    id: "DEL-002",
    pickup: "789 Pine Rd, Galway",
    delivery: "321 Elm St, Galway",
    status: "pending",
    driver: "Jane Smith",
    createdAt: "2024-03-20T11:30:00Z",
  },
  {
    id: "DEL-003",
    pickup: "555 Cedar Ln, Cork",
    delivery: "777 Maple Dr, Cork",
    status: "completed",
    driver: "Mike Johnson",
    createdAt: "2024-03-20T09:15:00Z",
  },
  {
    id: "DEL-004",
    pickup: "888 Birch St, Limerick",
    delivery: "999 Ash Ave, Limerick",
    status: "cancelled",
    driver: "Sarah Wilson",
    createdAt: "2024-03-20T08:45:00Z",
  },
];