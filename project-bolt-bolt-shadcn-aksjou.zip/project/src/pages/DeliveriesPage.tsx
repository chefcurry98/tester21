import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { DataTable } from '@/components/ui/data-table';
import { deliveriesColumns } from '@/components/deliveries/columns';
import { deliveriesData } from '@/data/deliveries';

export function DeliveriesPage() {
  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>All Deliveries</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable columns={deliveriesColumns} data={deliveriesData} />
        </CardContent>
      </Card>
    </div>
  );
}