import { useState } from 'react';
import { motion } from 'framer-motion';
import { DeliveryStats } from '@/components/dashboard/DeliveryStats';
import { DeliveryMap } from '@/components/dashboard/DeliveryMap';
import { ActiveDeliveries } from '@/components/dashboard/ActiveDeliveries';
import { DemandInsights } from '@/components/dashboard/DemandInsights';
import { NewDeliveryForm } from '@/components/dashboard/NewDeliveryForm';
import { DeliveryProgress } from '@/components/dashboard/DeliveryProgress';
import { useMediaQuery } from '@/hooks/use-media-query';
import { ANIMATION_CONFIG } from '@/config/constants';

export function DashboardPage() {
  const [showNewDeliveryForm, setShowNewDeliveryForm] = useState(false);
  const [selectedDelivery, setSelectedDelivery] = useState<any>(null);
  const isTablet = useMediaQuery('(max-width: 1024px)');

  const handleDeliveryClick = (delivery: any) => {
    setSelectedDelivery({
      ...delivery,
      progress: 65,
      estimatedTime: '10 mins away'
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={ANIMATION_CONFIG.fade}
      className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto"
    >
      <DeliveryStats />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        <motion.div 
          className="lg:col-span-2 space-y-4 md:space-y-6"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ ...ANIMATION_CONFIG.spring, delay: 0.2 }}
        >
          <div className="h-[300px] md:h-[400px]">
            <DeliveryMap />
          </div>
          {!isTablet && <DemandInsights />}
        </motion.div>

        <motion.div 
          className="space-y-4 md:space-y-6"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ ...ANIMATION_CONFIG.spring, delay: 0.3 }}
        >
          <ActiveDeliveries 
            onNewDelivery={() => setShowNewDeliveryForm(true)}
            onDeliveryClick={handleDeliveryClick}
          />
        </motion.div>
      </div>

      {isTablet && (
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ ...ANIMATION_CONFIG.spring, delay: 0.4 }}
        >
          <DemandInsights />
        </motion.div>
      )}
      
      <NewDeliveryForm 
        open={showNewDeliveryForm} 
        onClose={() => setShowNewDeliveryForm(false)} 
      />
      
      {selectedDelivery && (
        <DeliveryProgress
          delivery={selectedDelivery}
          open={!!selectedDelivery}
          onClose={() => setSelectedDelivery(null)}
        />
      )}
    </motion.div>
  );
}