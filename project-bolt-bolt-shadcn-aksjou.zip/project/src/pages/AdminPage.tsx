import { useState } from 'react';
import { EmployeeList } from '@/components/admin/EmployeeList';
import { EmployeeForm } from '@/components/admin/EmployeeForm';
import { employeesData } from '@/data/employees';
import { Employee } from '@/types/employee';

export function AdminPage() {
  const [showEmployeeForm, setShowEmployeeForm] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | undefined>();

  const handleAddEmployee = () => {
    setSelectedEmployee(undefined);
    setShowEmployeeForm(true);
  };

  const handleEditEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setShowEmployeeForm(true);
  };

  return (
    <div className="p-6 space-y-6">
      <EmployeeList
        employees={employeesData}
        onAddEmployee={handleAddEmployee}
        onEditEmployee={handleEditEmployee}
      />
      
      <EmployeeForm
        open={showEmployeeForm}
        onClose={() => setShowEmployeeForm(false)}
        employee={selectedEmployee}
      />
    </div>
  );
}