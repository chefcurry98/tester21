import { Badge } from "@/components/ui/badge";
import { DeliveryStatus } from "@/types/delivery";

export const deliveriesColumns = [
  {
    accessorKey: "id",
    header: "ID",
  },
  {
    accessorKey: "pickup",
    header: "Pickup Location",
  },
  {
    accessorKey: "delivery",
    header: "Delivery Location",
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }: { row: { original: { status: DeliveryStatus } } }) => {
      const status = row.original.status;
      const statusColors = {
        pending: "bg-yellow-100 text-yellow-800",
        inProgress: "bg-blue-100 text-blue-800",
        completed: "bg-green-100 text-green-800",
        cancelled: "bg-red-100 text-red-800",
      };

      return (
        <Badge className={statusColors[status]}>
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </Badge>
      );
    },
  },
  {
    accessorKey: "driver",
    header: "Driver",
  },
  {
    accessorKey: "createdAt",
    header: "Created At",
    cell: ({ row }: { row: { original: { createdAt: string } } }) => {
      return new Date(row.original.createdAt).toLocaleDateString();
    },
  },
];