import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';
import { Package, Clock, MapPin } from 'lucide-react';

interface ScheduledDeliveriesProps {
  selectedDate?: Date;
}

export function ScheduledDeliveries({ selectedDate }: ScheduledDeliveriesProps) {
  const deliveries = [
    {
      id: 1,
      time: '09:00 AM',
      address: '123 Main St, Dublin',
      items: 'Food Delivery',
      status: 'Scheduled'
    },
    {
      id: 2,
      time: '02:30 PM',
      address: '456 Oak Ave, Galway',
      items: 'Electronics',
      status: 'Scheduled'
    },
    // Add more scheduled deliveries as needed
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Scheduled Deliveries for {selectedDate ? format(selectedDate, 'PPP') : 'Today'}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {deliveries.map((delivery) => (
          <div
            key={delivery.id}
            className="p-4 border rounded-lg space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Package className="h-5 w-5 text-[#8B9D5E]" />
                <span className="font-medium">{delivery.items}</span>
              </div>
              <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                {delivery.status}
              </span>
            </div>
            
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>{delivery.time}</span>
            </div>
            
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>{delivery.address}</span>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}