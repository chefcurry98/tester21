import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export function LoginForm() {
  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">Please Login with your email</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Input type="email" placeholder="Email" className="w-full" />
        <Input type="password" placeholder="Password" className="w-full" />
        
        <Button className="w-full bg-[#8B9D5E] hover:bg-[#7A8B4D]">
          Login
        </Button>
        
        <div className="text-center text-sm text-muted-foreground">OR</div>
        
        <Button variant="outline" className="w-full">
          <img src="/google.svg" alt="Google" className="w-5 h-5 mr-2" />
          Continue with Google
        </Button>
        
        <Button variant="outline" className="w-full">
          <img src="/apple.svg" alt="Apple" className="w-5 h-5 mr-2" />
          Continue with Apple ID
        </Button>
        
        <Button variant="outline" className="w-full">
          <img src="/facebook.svg" alt="Facebook" className="w-5 h-5 mr-2" />
          Continue with Facebook
        </Button>
        
        <Separator />
        
        <div className="text-center">
          <span className="text-sm text-muted-foreground">Don't Have an account? </span>
          <Button variant="link" className="text-[#8B9D5E] p-0">
            Register
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}