import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin } from "lucide-react";

export function PersonalInfo() {
  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">Personal Info</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">First Name</label>
          <Input placeholder="Enter first name" />
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Surname</label>
          <Input placeholder="Enter second name" />
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Eir-tag</label>
          <Input placeholder="Enter your eir-tag name" />
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Location</label>
          <div className="relative">
            <Input placeholder="Enter your location" />
            <MapPin className="absolute right-3 top-2.5 h-5 w-5 text-muted-foreground" />
          </div>
        </div>
        
        <Button className="w-full bg-[#8B9D5E] hover:bg-[#7A8B4D] mt-4">
          Finish Setup
        </Button>
      </CardContent>
    </Card>
  );
}