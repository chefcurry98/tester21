import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function OTPVerification() {
  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">OTP Verification</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <p className="text-center text-muted-foreground">
          Enter the 4-digit code sent to you at
          <br />
          <span className="font-semibold">e****@gmail.com</span>
        </p>
        
        <div className="flex justify-center gap-2">
          <Input className="w-12 h-12 text-center text-lg" maxLength={1} />
          <Input className="w-12 h-12 text-center text-lg" maxLength={1} />
          <Input className="w-12 h-12 text-center text-lg" maxLength={1} />
          <Input className="w-12 h-12 text-center text-lg" maxLength={1} />
        </div>
        
        <Button className="w-full bg-[#8B9D5E] hover:bg-[#7A8B4D]">
          Continue
        </Button>
        
        <div className="text-center">
          <span className="text-sm text-muted-foreground">Didn't receive a code? </span>
          <Button variant="link" className="text-[#8B9D5E] p-0">
            Resend
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}