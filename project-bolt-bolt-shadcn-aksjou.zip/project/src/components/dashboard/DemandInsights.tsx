import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { DemandChart } from './charts/DemandChart';
import { DemandStats } from './charts/components/DemandStats';
import { DemandLegend } from './charts/components/DemandLegend';
import { demandData } from '@/data/demand-data';
import { useState } from 'react';

const timeRanges = [
  { value: 'week', label: 'Weekly' },
  { value: 'month', label: 'Monthly' },
  { value: 'year', label: 'Yearly' },
] as const;

export function DemandInsights() {
  const [selectedRange, setSelectedRange] = useState<typeof timeRanges[number]['value']>('week');

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle>Product Demand Trends</CardTitle>
        <Tabs value={selectedRange} onValueChange={setSelectedRange}>
          <TabsList className="grid w-[300px] grid-cols-3">
            {timeRanges.map(({ value, label }) => (
              <TabsTrigger key={value} value={value}>
                {label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-4">
          <DemandStats data={demandData} />
        </div>
        <div className="h-[300px]">
          <DemandChart data={demandData} />
        </div>
        <DemandLegend />
      </CardContent>
    </Card>
  );
}