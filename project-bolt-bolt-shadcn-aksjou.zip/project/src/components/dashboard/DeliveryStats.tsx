import { Card, CardContent } from '@/components/ui/card';
import { Package, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ANIMATION_CONFIG } from '@/config/constants';

export function DeliveryStats() {
  const navigate = useNavigate();
  
  const stats = [
    {
      title: "Active Deliveries",
      value: "12",
      icon: Package,
      color: "text-blue-500",
      bg: "bg-blue-100",
      link: "/deliveries?status=active"
    },
    {
      title: "Completed Today",
      value: "48",
      icon: CheckCircle,
      color: "text-green-500",
      bg: "bg-green-100",
      link: "/deliveries?status=completed"
    },
    {
      title: "Pending",
      value: "6",
      icon: Clock,
      color: "text-orange-500",
      bg: "bg-orange-100",
      link: "/deliveries?status=pending"
    },
    {
      title: "Issues",
      value: "2",
      icon: AlertCircle,
      color: "text-red-500",
      bg: "bg-red-100",
      link: "/deliveries?status=issues"
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ ...ANIMATION_CONFIG.spring, delay: index * 0.1 }}
        >
          <Card 
            className="cursor-pointer transition-all hover:shadow-lg active:scale-95"
            onClick={() => navigate(stat.link)}
          >
            <CardContent className="p-4 md:p-6">
              <div className="flex flex-col md:flex-row md:items-center md:space-x-4">
                <div className={`p-3 rounded-full ${stat.bg} mb-4 md:mb-0`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {stat.title}
                  </p>
                  <h3 className="text-2xl font-bold mt-1">{stat.value}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}