import { CategoricalChartProps } from 'recharts';

export const chartDefaults = {
  margin: { top: 5, right: 30, left: 20, bottom: 5 },
  gridProps: {
    strokeDasharray: '3 3',
  },
  axisStyle: {
    tick: { fill: '#888888' },
    tickLine: { stroke: '#888888' },
    axisLine: { stroke: '#888888' },
  },
  tooltipStyle: {
    contentStyle: {
      backgroundColor: 'white',
      border: '1px solid #e2e8f0',
      borderRadius: '6px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    },
  },
  legendProps: {
    verticalAlign: 'bottom' as const,
    height: 36,
    iconType: 'circle' as const,
  },
  lineDefaults: {
    type: 'monotone' as const,
    strokeWidth: 2,
    dotConfig: (color: string) => ({
      dot: { fill: color, r: 4 },
      activeDot: { r: 6, fill: color },
    }),
  },
};

export const lineColors = {
  food: '#8B9D5E',
  electronics: '#82ca9d',
  clothing: '#ffc658',
} as const;