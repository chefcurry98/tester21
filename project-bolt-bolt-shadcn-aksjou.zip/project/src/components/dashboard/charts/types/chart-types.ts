export interface DemandData {
  name: string;
  food: number;
  electronics: number;
  clothing: number;
}

export interface ChartConfig {
  margin: {
    top: number;
    right: number;
    left: number;
    bottom: number;
  };
  gridProps: {
    strokeDasharray: string;
  };
  axisStyle: {
    tick: { fill: string };
    tickLine: { stroke: string };
    axisLine: { stroke: string };
  };
  tooltipStyle: {
    contentStyle: {
      backgroundColor: string;
      border: string;
      borderRadius: string;
      boxShadow: string;
    };
  };
  legendProps: {
    verticalAlign: 'top' | 'middle' | 'bottom';
    height: number;
    iconType: 'circle';
  };
  lineDefaults: {
    type: 'monotone';
    strokeWidth: number;
    dotConfig: (color: string) => {
      dot: { fill: string; r: number };
      activeDot: { r: number; fill: string };
    };
  };
  lineColors: {
    food: string;
    electronics: string;
    clothing: string;
  };
}