import { Line } from 'recharts';
import { chartConfig } from '../config/chart-config';

interface LineProps {
  dataKey: string;
  color: string;
  name: string;
}

export function ChartLine({ dataKey, color, name }: LineProps) {
  const { dot, activeDot } = chartConfig.lineDefaults.dotConfig(color);
  
  return (
    <Line
      type={chartConfig.lineDefaults.type}
      dataKey={dataKey}
      name={name}
      stroke={color}
      strokeWidth={chartConfig.lineDefaults.strokeWidth}
      dot={dot}
      activeDot={activeDot}
    />
  );
}