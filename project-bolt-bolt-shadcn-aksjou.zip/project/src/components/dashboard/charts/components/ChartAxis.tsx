import { XAxis, YAxis } from 'recharts';
import { chartConfig } from '../config/chart-config';

interface AxisProps {
  dataKey?: string;
}

export function ChartXAxis({ dataKey }: AxisProps) {
  return (
    <XAxis
      dataKey={dataKey}
      padding={{ left: 0, right: 0 }}
      {...chartConfig.axisStyle}
    />
  );
}

export function ChartYAxis() {
  return (
    <YAxis {...chartConfig.axisStyle} />
  );
}