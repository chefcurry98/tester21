import { Badge } from '@/components/ui/badge';

const categories = [
  { name: 'Food', color: '#8B9D5E' },
  { name: 'Electronics', color: '#82ca9d' },
  { name: 'Clothing', color: '#ffc658' },
];

export function DemandLegend() {
  return (
    <div className="flex justify-center gap-4 mt-4">
      {categories.map(({ name, color }) => (
        <div key={name} className="flex items-center gap-2">
          <div
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: color }}
          />
          <span className="text-sm text-muted-foreground">{name}</span>
        </div>
      ))}
    </div>
  );
}