import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { DemandData } from '../types/chart-types';

interface DemandStatsProps {
  data: DemandData[];
}

export function DemandStats({ data }: DemandStatsProps) {
  const categories = ['food', 'electronics', 'clothing'] as const;
  
  const calculateGrowth = (category: typeof categories[number]) => {
    const lastIndex = data.length - 1;
    const currentValue = data[lastIndex][category];
    const previousValue = data[lastIndex - 1][category];
    const growth = ((currentValue - previousValue) / previousValue) * 100;
    return growth;
  };

  return (
    <>
      {categories.map((category) => {
        const growth = calculateGrowth(category);
        const isPositive = growth > 0;
        
        return (
          <Card key={category}>
            <CardContent className="pt-6">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </p>
                  <h4 className="text-2xl font-bold">
                    {data[data.length - 1][category]}
                  </h4>
                </div>
                <div className={`p-2 rounded-full ${
                  isPositive ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  {isPositive ? (
                    <TrendingUp className="h-4 w-4 text-green-600" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-600" />
                  )}
                </div>
              </div>
              <p className={`text-sm mt-2 ${
                isPositive ? 'text-green-600' : 'text-red-600'
              }`}>
                {isPositive ? '+' : ''}{growth.toFixed(1)}% from last period
              </p>
            </CardContent>
          </Card>
        );
      })}
    </>
  );
}