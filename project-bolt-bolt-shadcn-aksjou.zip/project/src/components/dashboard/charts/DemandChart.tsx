import { LineChart, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ChartXAxis, ChartYAxis } from './components/ChartAxis';
import { ChartLine } from './components/ChartLine';
import { DemandData } from './types/chart-types';
import { chartConfig } from './config/chart-config';

interface DemandChartProps {
  data: DemandData[];
}

export function DemandChart({ data }: DemandChartProps) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={data}
        margin={chartConfig.margin}
      >
        <CartesianGrid strokeDasharray={chartConfig.gridProps.strokeDasharray} />
        <ChartXAxis dataKey="name" />
        <ChartYAxis />
        <Tooltip {...chartConfig.tooltipStyle} />
        <Legend {...chartConfig.legendProps} />
        
        {Object.entries(chartConfig.lineColors).map(([key, color]) => (
          <ChartLine
            key={key}
            dataKey={key}
            color={color}
            name={key.charAt(0).toUpperCase() + key.slice(1)}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}