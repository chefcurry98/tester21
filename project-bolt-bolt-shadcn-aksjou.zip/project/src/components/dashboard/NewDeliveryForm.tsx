import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

interface NewDeliveryFormProps {
  open: boolean;
  onClose: () => void;
}

export function NewDeliveryForm({ open, onClose }: NewDeliveryFormProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create New Delivery</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Pickup Location</Label>
            <Input placeholder="Enter pickup address" />
          </div>
          <div className="space-y-2">
            <Label>Delivery Location</Label>
            <Input placeholder="Enter delivery address" />
          </div>
          <div className="space-y-2">
            <Label>Package Details</Label>
            <Input placeholder="Enter package description" />
          </div>
          <div className="space-y-2">
            <Label>Special Instructions</Label>
            <Input placeholder="Any special handling instructions" />
          </div>
          <Button className="w-full bg-[#8B9D5E] hover:bg-[#7A8B4D]">
            Create Delivery
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}