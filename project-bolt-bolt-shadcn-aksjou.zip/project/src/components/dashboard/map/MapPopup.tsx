import { Popup } from 'react-map-gl';
import { Delivery, Driver } from '@/types/map';

interface MapPopupProps {
  item: Delivery | Driver;
  onClose: () => void;
}

export function MapPopup({ item, onClose }: MapPopupProps) {
  const isDelivery = 'address' in item;

  return (
    <Popup
      longitude={item.coordinates[0]}
      latitude={item.coordinates[1]}
      anchor="bottom"
      onClose={onClose}
      className="z-50"
    >
      <div className="p-2">
        {isDelivery ? (
          <>
            <h3 className="font-semibold">Delivery</h3>
            <p className="text-sm">{(item as Delivery).address}</p>
            <p className="text-sm text-muted-foreground">
              Status: {item.status}
            </p>
            <p className="text-sm text-muted-foreground">
              Driver: {(item as Delivery).driver}
            </p>
          </>
        ) : (
          <>
            <h3 className="font-semibold">Driver</h3>
            <p className="text-sm">{(item as Driver).name}</p>
            <p className="text-sm text-muted-foreground">
              Status: {item.status}
            </p>
          </>
        )}
      </div>
    </Popup>
  );
}