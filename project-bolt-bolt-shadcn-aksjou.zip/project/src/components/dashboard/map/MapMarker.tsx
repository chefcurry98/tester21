import { Marker } from 'react-map-gl';
import { Package, User } from 'lucide-react';
import { Delivery, Driver } from '@/types/map';

interface MapMarkerProps {
  item: Delivery | Driver;
  onClick: (item: Delivery | Driver) => void;
}

export function MapMarker({ item, onClick }: MapMarkerProps) {
  const isDelivery = 'address' in item;

  return (
    <Marker
      longitude={item.coordinates[0]}
      latitude={item.coordinates[1]}
      anchor="bottom"
      onClick={(e) => {
        e.originalEvent.stopPropagation();
        onClick(item);
      }}
    >
      {isDelivery ? (
        <Package className="h-6 w-6 text-[#8B9D5E] cursor-pointer" />
      ) : (
        <User className="h-6 w-6 text-blue-500 cursor-pointer" />
      )}
    </Marker>
  );
}