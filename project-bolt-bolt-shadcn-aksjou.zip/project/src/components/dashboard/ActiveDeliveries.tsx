import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Package, MapPin, Clock } from 'lucide-react';

interface ActiveDeliveriesProps {
  onNewDelivery: () => void;
  onDeliveryClick: (delivery: any) => void;
}

export function ActiveDeliveries({ onNewDelivery, onDeliveryClick }: ActiveDeliveriesProps) {
  const deliveries = [
    {
      id: "DEL-001",
      address: "123 Main St, Dublin",
      status: "In Progress",
      time: "10 mins away",
      driver: "John Doe"
    },
    {
      id: "DEL-002",
      address: "456 Oak Ave, Galway",
      status: "Picking Up",
      time: "Starting soon",
      driver: "Jane Smith"
    }
  ];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Active Deliveries</CardTitle>
        <Button onClick={onNewDelivery} className="bg-[#8B9D5E] hover:bg-[#7A8B4D]">
          New Delivery
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {deliveries.map((delivery) => (
          <div
            key={delivery.id}
            className="p-4 border rounded-lg space-y-3 cursor-pointer hover:shadow-md transition-all"
            onClick={() => onDeliveryClick(delivery)}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-2">
                <Package className="h-5 w-5 text-[#8B9D5E]" />
                <span className="font-medium">Delivery #{delivery.id}</span>
              </div>
              <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                {delivery.status}
              </span>
            </div>
            
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>{delivery.address}</span>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4" />
                <span>{delivery.time}</span>
              </div>
              <span className="text-[#8B9D5E]">{delivery.driver}</span>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}