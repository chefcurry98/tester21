import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Package, MapPin, User, Clock } from 'lucide-react';

interface DeliveryProgressProps {
  delivery: {
    id: string;
    status: string;
    address: string;
    driver: string;
    estimatedTime: string;
    progress: number;
  };
  open: boolean;
  onClose: () => void;
}

export function DeliveryProgress({ delivery, open, onClose }: DeliveryProgressProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Delivery #{delivery.id}
            <Badge className="bg-blue-100 text-blue-800">
              {delivery.status}
            </Badge>
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-6 py-4">
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <MapPin className="h-5 w-5 text-gray-500" />
              <div>
                <p className="text-sm font-medium">Delivery Address</p>
                <p className="text-sm text-gray-500">{delivery.address}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <User className="h-5 w-5 text-gray-500" />
              <div>
                <p className="text-sm font-medium">Driver</p>
                <p className="text-sm text-gray-500">{delivery.driver}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Clock className="h-5 w-5 text-gray-500" />
              <div>
                <p className="text-sm font-medium">Estimated Time</p>
                <p className="text-sm text-gray-500">{delivery.estimatedTime}</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>{delivery.progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-[#8B9D5E] h-2.5 rounded-full transition-all duration-500"
                style={{ width: `${delivery.progress}%` }}
              ></div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}