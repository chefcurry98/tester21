import { useRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Map, { NavigationControl, ViewState } from 'react-map-gl';
import { MapMarker } from './map/MapMarker';
import { MapPopup } from './map/MapPopup';
import { Delivery, Driver } from '@/types/map';
import { deliveriesData, driversData } from '@/data/map-data';
import { MAPBOX_TOKEN, MAP_STYLE, DUBLIN_COORDINATES } from '@/config/constants';
import { useMediaQuery } from '@/hooks/use-media-query';
import 'mapbox-gl/dist/mapbox-gl.css';

export function DeliveryMap() {
  const mapRef = useRef(null);
  const [selectedMarker, setSelectedMarker] = useState<Delivery | Driver | null>(null);
  const [viewState, setViewState] = useState<Partial<ViewState>>(DUBLIN_COORDINATES);
  const isMobile = useMediaQuery('(max-width: 768px)');

  return (
    <Card className="relative h-full">
      <CardContent className="p-0 h-full">
        <div className="absolute top-4 right-4 z-10 flex flex-col md:flex-row gap-2">
          <Badge variant="secondary" className="bg-green-100 text-green-800 whitespace-nowrap">
            {driversData.length} Active Drivers
          </Badge>
          <Badge variant="secondary" className="bg-blue-100 text-blue-800 whitespace-nowrap">
            {deliveriesData.length} Deliveries
          </Badge>
        </div>
        
        <div className="w-full h-full rounded-lg overflow-hidden">
          <Map
            ref={mapRef}
            mapboxAccessToken={MAPBOX_TOKEN}
            {...viewState}
            onMove={evt => setViewState(evt.viewState)}
            style={{ width: '100%', height: '100%' }}
            mapStyle={MAP_STYLE}
            dragRotate={false}
            touchZoomRotate={true}
          >
            <NavigationControl position={isMobile ? 'bottom-right' : 'top-right'} />

            {deliveriesData.map((delivery) => (
              <MapMarker
                key={delivery.id}
                item={delivery}
                onClick={setSelectedMarker}
              />
            ))}

            {driversData.map((driver) => (
              <MapMarker
                key={driver.id}
                item={driver}
                onClick={setSelectedMarker}
              />
            ))}

            {selectedMarker && (
              <MapPopup
                item={selectedMarker}
                onClose={() => setSelectedMarker(null)}
              />
            )}
          </Map>
        </div>
      </CardContent>
    </Card>
  );
}