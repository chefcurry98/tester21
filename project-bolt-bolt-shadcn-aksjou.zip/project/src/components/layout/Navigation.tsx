import { Home, Map, Calendar, User } from "lucide-react";

export function Navigation() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t">
      <div className="flex justify-around p-4 max-w-md mx-auto">
        <button className="flex flex-col items-center text-[#8B9D5E]">
          <Home className="h-6 w-6" />
          <span className="text-xs mt-1">Home</span>
        </button>
        <button className="flex flex-col items-center text-muted-foreground">
          <Map className="h-6 w-6" />
          <span className="text-xs mt-1">Destinations</span>
        </button>
        <button className="flex flex-col items-center text-muted-foreground">
          <Calendar className="h-6 w-6" />
          <span className="text-xs mt-1">Bookings</span>
        </button>
        <button className="flex flex-col items-center text-muted-foreground">
          <User className="h-6 w-6" />
          <span className="text-xs mt-1">Account</span>
        </button>
      </div>
    </nav>
  );
}