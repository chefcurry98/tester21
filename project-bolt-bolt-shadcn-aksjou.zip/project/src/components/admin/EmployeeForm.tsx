import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Employee, EmployeeRole, EmployeeStatus } from "@/types/employee";

interface EmployeeFormProps {
  open: boolean;
  onClose: () => void;
  employee?: Employee;
}

export function EmployeeForm({ open, onClose, employee }: EmployeeFormProps) {
  const isEditing = !!employee;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? 'Edit Employee' : 'Add New Employee'}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input 
              placeholder="Enter full name"
              defaultValue={employee?.name}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Email</Label>
            <Input 
              type="email"
              placeholder="Enter email address"
              defaultValue={employee?.email}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Phone</Label>
            <Input 
              placeholder="Enter phone number"
              defaultValue={employee?.phone}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Role</Label>
            <Select defaultValue={employee?.role}>
              <SelectTrigger>
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="driver">Driver</SelectItem>
                <SelectItem value="dispatcher">Dispatcher</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Status</Label>
            <Select defaultValue={employee?.status}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="onLeave">On Leave</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button className="w-full bg-[#8B9D5E] hover:bg-[#7A8B4D]">
            {isEditing ? 'Update Employee' : 'Add Employee'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}