import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Employee } from "@/types/employee";
import { UserPlus } from "lucide-react";

interface EmployeeListProps {
  employees: Employee[];
  onAddEmployee: () => void;
  onEditEmployee: (employee: Employee) => void;
}

export function EmployeeList({ employees, onAddEmployee, onEditEmployee }: EmployeeListProps) {
  const getStatusColor = (status: Employee['status']) => {
    const colors = {
      active: "bg-green-100 text-green-800",
      inactive: "bg-red-100 text-red-800",
      onLeave: "bg-yellow-100 text-yellow-800"
    };
    return colors[status];
  };

  const getRoleColor = (role: Employee['role']) => {
    const colors = {
      driver: "bg-blue-100 text-blue-800",
      dispatcher: "bg-purple-100 text-purple-800",
      admin: "bg-gray-100 text-gray-800"
    };
    return colors[role];
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Employees</CardTitle>
        <Button onClick={onAddEmployee} className="bg-[#8B9D5E] hover:bg-[#7A8B4D]">
          <UserPlus className="h-4 w-4 mr-2" />
          Add Employee
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {employees.map((employee) => (
            <div
              key={employee.id}
              className="p-4 border rounded-lg hover:shadow-md transition-all cursor-pointer"
              onClick={() => onEditEmployee(employee)}
            >
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="font-medium">{employee.name}</h3>
                  <p className="text-sm text-muted-foreground">{employee.email}</p>
                </div>
                <div className="flex gap-2">
                  <Badge className={getRoleColor(employee.role)}>
                    {employee.role}
                  </Badge>
                  <Badge className={getStatusColor(employee.status)}>
                    {employee.status}
                  </Badge>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Phone:</span>
                  <span className="ml-2">{employee.phone}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Joined:</span>
                  <span className="ml-2">
                    {new Date(employee.joinDate).toLocaleDateString()}
                  </span>
                </div>
                {employee.role === 'driver' && (
                  <>
                    <div>
                      <span className="text-muted-foreground">Deliveries:</span>
                      <span className="ml-2">{employee.deliveriesCompleted}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Rating:</span>
                      <span className="ml-2">{employee.rating} / 5</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}