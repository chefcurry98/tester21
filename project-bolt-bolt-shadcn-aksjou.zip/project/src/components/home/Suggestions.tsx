import { Card, CardContent } from "@/components/ui/card";
import { Send, Leaf, Heart } from "lucide-react";

export function Suggestions() {
  const suggestions = [
    { icon: <Send className="h-6 w-6" />, title: "Send here", color: "bg-blue-100" },
    { icon: <Leaf className="h-6 w-6" />, title: "Schedule", color: "bg-green-100" },
    { icon: <Heart className="h-6 w-6" />, title: "How To/Info", color: "bg-pink-100" },
  ];

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Suggestions</h2>
      <div className="flex gap-4">
        {suggestions.map((item, index) => (
          <Card key={index} className="flex-1">
            <CardContent className={`flex flex-col items-center justify-center p-4 ${item.color} rounded-lg`}>
              {item.icon}
              <span className="text-sm mt-2">{item.title}</span>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}