export type EmployeeRole = "driver" | "dispatcher" | "admin";
export type EmployeeStatus = "active" | "inactive" | "onLeave";

export interface Employee {
  id: string;
  name: string;
  email: string;
  role: EmployeeRole;
  status: EmployeeStatus;
  joinDate: string;
  phone: string;
  deliveriesCompleted?: number;
  rating?: number;
}