export type DeliveryStatus = "pending" | "inProgress" | "completed" | "cancelled";

export interface Delivery {
  id: string;
  pickup: string;
  delivery: string;
  status: DeliveryStatus;
  driver: string;
  createdAt: string;
}