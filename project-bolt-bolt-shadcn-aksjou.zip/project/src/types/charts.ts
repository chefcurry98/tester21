import { CategoricalChartProps } from 'recharts';

export interface DemandData {
  name: string;
  food: number;
  electronics: number;
  clothing: number;
}

export interface ChartConfig {
  margin: CategoricalChartProps['margin'];
  gridProps: {
    strokeDasharray: string;
  };
  axisStyle: {
    tick: { fill: string };
    tickLine: { stroke: string };
    axisLine: { stroke: string };
  };
  tooltipStyle: {
    contentStyle: {
      backgroundColor: string;
      border: string;
      borderRadius: string;
      boxShadow: string;
    };
  };
  legendProps: {
    verticalAlign: 'top' | 'middle' | 'bottom';
    height: number;
    iconType: 'line' | 'square' | 'rect' | 'circle' | 'cross' | 'diamond' | 'star' | 'triangle' | 'wye';
  };
  lineDefaults: {
    type: 'basis' | 'basisClosed' | 'basisOpen' | 'linear' | 'linearClosed' | 'natural' | 'monotoneX' | 'monotoneY' | 'monotone' | 'step' | 'stepBefore' | 'stepAfter';
    strokeWidth: number;
    dotConfig: (color: string) => {
      dot: { fill: string; r: number };
      activeDot: { r: number; fill: string };
    };
  };
}