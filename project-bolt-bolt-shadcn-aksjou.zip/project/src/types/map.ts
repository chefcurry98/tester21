export interface Coordinates {
  longitude: number;
  latitude: number;
}

export interface Delivery {
  id: string;
  coordinates: [number, number];
  status: string;
  address: string;
  driver: string;
}

export interface Driver {
  id: string;
  coordinates: [number, number];
  name: string;
  status: string;
}