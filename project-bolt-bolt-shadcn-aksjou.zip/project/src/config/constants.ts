export const MAPBOX_TOKEN = 'pk.eyJ1IjoiZWlyY29ubmVjdCIsImEiOiJjbHRwOWY4Z2gwMXpqMnFxZWR2Z2hoY2NqIn0.tJlXwxz_-UDrDqzL8Uvz7A';

export const MAP_STYLE = 'mapbox://styles/mapbox/streets-v12';

export const DUBLIN_COORDINATES = {
  longitude: -6.2603,
  latitude: 53.3498,
  zoom: 12,
} as const;

export const ANIMATION_CONFIG = {
  spring: {
    type: "spring",
    bounce: 0.3,
    duration: 0.6,
  },
  fade: {
    duration: 0.3,
  },
} as const;